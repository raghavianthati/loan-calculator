function calculateEMI() {

    let principal = parseFloat(document.getElementById("amount").value);
    let annualRate = parseFloat(document.getElementById("interest").value);
    let months = parseInt(document.getElementById("months").value);

    if (isNaN(principal) || isNaN(annualRate) || isNaN(months)) {
        alert("Please enter all values.");
        return;
    }

    let monthlyRate = annualRate / 12 / 100;

    let emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) /
              (Math.pow(1 + monthlyRate, months) - 1);

    let totalPayment = emi * months;
    let totalInterest = totalPayment - principal;

    document.getElementById("emi").innerHTML = "₹" + emi.toFixed(2);
    document.getElementById("totalInterest").innerHTML = "₹" + totalInterest.toFixed(2);
    document.getElementById("totalPayment").innerHTML = "₹" + totalPayment.toFixed(2);

}